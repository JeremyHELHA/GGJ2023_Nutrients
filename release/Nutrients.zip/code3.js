gdjs.Level4Code = {};
gdjs.Level4Code.GDGoutteObjects1= [];
gdjs.Level4Code.GDGoutteObjects2= [];
gdjs.Level4Code.GDGoutteObjects3= [];
gdjs.Level4Code.GDGoutteObjects4= [];
gdjs.Level4Code.GDBackgroundSkyObjects1= [];
gdjs.Level4Code.GDBackgroundSkyObjects2= [];
gdjs.Level4Code.GDBackgroundSkyObjects3= [];
gdjs.Level4Code.GDBackgroundSkyObjects4= [];
gdjs.Level4Code.GDNutrientObjects1= [];
gdjs.Level4Code.GDNutrientObjects2= [];
gdjs.Level4Code.GDNutrientObjects3= [];
gdjs.Level4Code.GDNutrientObjects4= [];
gdjs.Level4Code.GDGrassObjects1= [];
gdjs.Level4Code.GDGrassObjects2= [];
gdjs.Level4Code.GDGrassObjects3= [];
gdjs.Level4Code.GDGrassObjects4= [];
gdjs.Level4Code.GDDirt_95GrassObjects1= [];
gdjs.Level4Code.GDDirt_95GrassObjects2= [];
gdjs.Level4Code.GDDirt_95GrassObjects3= [];
gdjs.Level4Code.GDDirt_95GrassObjects4= [];
gdjs.Level4Code.GDTopMidDirtObjects1= [];
gdjs.Level4Code.GDTopMidDirtObjects2= [];
gdjs.Level4Code.GDTopMidDirtObjects3= [];
gdjs.Level4Code.GDTopMidDirtObjects4= [];
gdjs.Level4Code.GDMidDirtObjects1= [];
gdjs.Level4Code.GDMidDirtObjects2= [];
gdjs.Level4Code.GDMidDirtObjects3= [];
gdjs.Level4Code.GDMidDirtObjects4= [];
gdjs.Level4Code.GDMidDirt2Objects1= [];
gdjs.Level4Code.GDMidDirt2Objects2= [];
gdjs.Level4Code.GDMidDirt2Objects3= [];
gdjs.Level4Code.GDMidDirt2Objects4= [];
gdjs.Level4Code.GDBottomMidDirtObjects1= [];
gdjs.Level4Code.GDBottomMidDirtObjects2= [];
gdjs.Level4Code.GDBottomMidDirtObjects3= [];
gdjs.Level4Code.GDBottomMidDirtObjects4= [];
gdjs.Level4Code.GDBottomObjects1= [];
gdjs.Level4Code.GDBottomObjects2= [];
gdjs.Level4Code.GDBottomObjects3= [];
gdjs.Level4Code.GDBottomObjects4= [];
gdjs.Level4Code.GDBottomDirtObjects1= [];
gdjs.Level4Code.GDBottomDirtObjects2= [];
gdjs.Level4Code.GDBottomDirtObjects3= [];
gdjs.Level4Code.GDBottomDirtObjects4= [];
gdjs.Level4Code.GDBotBottomObjects1= [];
gdjs.Level4Code.GDBotBottomObjects2= [];
gdjs.Level4Code.GDBotBottomObjects3= [];
gdjs.Level4Code.GDBotBottomObjects4= [];
gdjs.Level4Code.GDRacineObjects1= [];
gdjs.Level4Code.GDRacineObjects2= [];
gdjs.Level4Code.GDRacineObjects3= [];
gdjs.Level4Code.GDRacineObjects4= [];
gdjs.Level4Code.GDPesticideObjects1= [];
gdjs.Level4Code.GDPesticideObjects2= [];
gdjs.Level4Code.GDPesticideObjects3= [];
gdjs.Level4Code.GDPesticideObjects4= [];
gdjs.Level4Code.GDTimerObjects1= [];
gdjs.Level4Code.GDTimerObjects2= [];
gdjs.Level4Code.GDTimerObjects3= [];
gdjs.Level4Code.GDTimerObjects4= [];
gdjs.Level4Code.GDRetriesObjects1= [];
gdjs.Level4Code.GDRetriesObjects2= [];
gdjs.Level4Code.GDRetriesObjects3= [];
gdjs.Level4Code.GDRetriesObjects4= [];
gdjs.Level4Code.GDExitObjects1= [];
gdjs.Level4Code.GDExitObjects2= [];
gdjs.Level4Code.GDExitObjects3= [];
gdjs.Level4Code.GDExitObjects4= [];
gdjs.Level4Code.GDSunObjects1= [];
gdjs.Level4Code.GDSunObjects2= [];
gdjs.Level4Code.GDSunObjects3= [];
gdjs.Level4Code.GDSunObjects4= [];
gdjs.Level4Code.GDTreeTrunk01Objects1= [];
gdjs.Level4Code.GDTreeTrunk01Objects2= [];
gdjs.Level4Code.GDTreeTrunk01Objects3= [];
gdjs.Level4Code.GDTreeTrunk01Objects4= [];
gdjs.Level4Code.GDTreeTrunk02Objects1= [];
gdjs.Level4Code.GDTreeTrunk02Objects2= [];
gdjs.Level4Code.GDTreeTrunk02Objects3= [];
gdjs.Level4Code.GDTreeTrunk02Objects4= [];
gdjs.Level4Code.GDTreeTrunk03Objects1= [];
gdjs.Level4Code.GDTreeTrunk03Objects2= [];
gdjs.Level4Code.GDTreeTrunk03Objects3= [];
gdjs.Level4Code.GDTreeTrunk03Objects4= [];
gdjs.Level4Code.GDTreeTrunk04Objects1= [];
gdjs.Level4Code.GDTreeTrunk04Objects2= [];
gdjs.Level4Code.GDTreeTrunk04Objects3= [];
gdjs.Level4Code.GDTreeTrunk04Objects4= [];
gdjs.Level4Code.GDGoObjects1= [];
gdjs.Level4Code.GDGoObjects2= [];
gdjs.Level4Code.GDGoObjects3= [];
gdjs.Level4Code.GDGoObjects4= [];
gdjs.Level4Code.GDReadyObjects1= [];
gdjs.Level4Code.GDReadyObjects2= [];
gdjs.Level4Code.GDReadyObjects3= [];
gdjs.Level4Code.GDReadyObjects4= [];
gdjs.Level4Code.GDVictoryObjects1= [];
gdjs.Level4Code.GDVictoryObjects2= [];
gdjs.Level4Code.GDVictoryObjects3= [];
gdjs.Level4Code.GDVictoryObjects4= [];
gdjs.Level4Code.GDBigRockObjects1= [];
gdjs.Level4Code.GDBigRockObjects2= [];
gdjs.Level4Code.GDBigRockObjects3= [];
gdjs.Level4Code.GDBigRockObjects4= [];
gdjs.Level4Code.GDBigRock_95BotLeftObjects1= [];
gdjs.Level4Code.GDBigRock_95BotLeftObjects2= [];
gdjs.Level4Code.GDBigRock_95BotLeftObjects3= [];
gdjs.Level4Code.GDBigRock_95BotLeftObjects4= [];
gdjs.Level4Code.GDBigRock_95BotRightObjects1= [];
gdjs.Level4Code.GDBigRock_95BotRightObjects2= [];
gdjs.Level4Code.GDBigRock_95BotRightObjects3= [];
gdjs.Level4Code.GDBigRock_95BotRightObjects4= [];
gdjs.Level4Code.GDBigRock_95TopLeftObjects1= [];
gdjs.Level4Code.GDBigRock_95TopLeftObjects2= [];
gdjs.Level4Code.GDBigRock_95TopLeftObjects3= [];
gdjs.Level4Code.GDBigRock_95TopLeftObjects4= [];
gdjs.Level4Code.GDBigRock_95TopRighObjects1= [];
gdjs.Level4Code.GDBigRock_95TopRighObjects2= [];
gdjs.Level4Code.GDBigRock_95TopRighObjects3= [];
gdjs.Level4Code.GDBigRock_95TopRighObjects4= [];
gdjs.Level4Code.GDMediumRockObjects1= [];
gdjs.Level4Code.GDMediumRockObjects2= [];
gdjs.Level4Code.GDMediumRockObjects3= [];
gdjs.Level4Code.GDMediumRockObjects4= [];
gdjs.Level4Code.GDMediumRock_95BotLeftObjects1= [];
gdjs.Level4Code.GDMediumRock_95BotLeftObjects2= [];
gdjs.Level4Code.GDMediumRock_95BotLeftObjects3= [];
gdjs.Level4Code.GDMediumRock_95BotLeftObjects4= [];
gdjs.Level4Code.GDMediumRock_95BotRightObjects1= [];
gdjs.Level4Code.GDMediumRock_95BotRightObjects2= [];
gdjs.Level4Code.GDMediumRock_95BotRightObjects3= [];
gdjs.Level4Code.GDMediumRock_95BotRightObjects4= [];
gdjs.Level4Code.GDMediumRock_95TopLeftObjects1= [];
gdjs.Level4Code.GDMediumRock_95TopLeftObjects2= [];
gdjs.Level4Code.GDMediumRock_95TopLeftObjects3= [];
gdjs.Level4Code.GDMediumRock_95TopLeftObjects4= [];
gdjs.Level4Code.GDMediumRock_95TopRightObjects1= [];
gdjs.Level4Code.GDMediumRock_95TopRightObjects2= [];
gdjs.Level4Code.GDMediumRock_95TopRightObjects3= [];
gdjs.Level4Code.GDMediumRock_95TopRightObjects4= [];
gdjs.Level4Code.GDSideWall_95CornerObjects1= [];
gdjs.Level4Code.GDSideWall_95CornerObjects2= [];
gdjs.Level4Code.GDSideWall_95CornerObjects3= [];
gdjs.Level4Code.GDSideWall_95CornerObjects4= [];
gdjs.Level4Code.GDTileSideWall_95DoubleObjects1= [];
gdjs.Level4Code.GDTileSideWall_95DoubleObjects2= [];
gdjs.Level4Code.GDTileSideWall_95DoubleObjects3= [];
gdjs.Level4Code.GDTileSideWall_95DoubleObjects4= [];
gdjs.Level4Code.GDTileSideWallObjects1= [];
gdjs.Level4Code.GDTileSideWallObjects2= [];
gdjs.Level4Code.GDTileSideWallObjects3= [];
gdjs.Level4Code.GDTileSideWallObjects4= [];
gdjs.Level4Code.GDTileRacine01Objects1= [];
gdjs.Level4Code.GDTileRacine01Objects2= [];
gdjs.Level4Code.GDTileRacine01Objects3= [];
gdjs.Level4Code.GDTileRacine01Objects4= [];
gdjs.Level4Code.GDExplosionObjects1= [];
gdjs.Level4Code.GDExplosionObjects2= [];
gdjs.Level4Code.GDExplosionObjects3= [];
gdjs.Level4Code.GDExplosionObjects4= [];
gdjs.Level4Code.GDTree02Objects1= [];
gdjs.Level4Code.GDTree02Objects2= [];
gdjs.Level4Code.GDTree02Objects3= [];
gdjs.Level4Code.GDTree02Objects4= [];
gdjs.Level4Code.GDTree02bObjects1= [];
gdjs.Level4Code.GDTree02bObjects2= [];
gdjs.Level4Code.GDTree02bObjects3= [];
gdjs.Level4Code.GDTree02bObjects4= [];
gdjs.Level4Code.GDTree02cObjects1= [];
gdjs.Level4Code.GDTree02cObjects2= [];
gdjs.Level4Code.GDTree02cObjects3= [];
gdjs.Level4Code.GDTree02cObjects4= [];
gdjs.Level4Code.GDTree02dObjects1= [];
gdjs.Level4Code.GDTree02dObjects2= [];
gdjs.Level4Code.GDTree02dObjects3= [];
gdjs.Level4Code.GDTree02dObjects4= [];
gdjs.Level4Code.GDTree02eObjects1= [];
gdjs.Level4Code.GDTree02eObjects2= [];
gdjs.Level4Code.GDTree02eObjects3= [];
gdjs.Level4Code.GDTree02eObjects4= [];
gdjs.Level4Code.GDTree02fObjects1= [];
gdjs.Level4Code.GDTree02fObjects2= [];
gdjs.Level4Code.GDTree02fObjects3= [];
gdjs.Level4Code.GDTree02fObjects4= [];
gdjs.Level4Code.GDTree03aObjects1= [];
gdjs.Level4Code.GDTree03aObjects2= [];
gdjs.Level4Code.GDTree03aObjects3= [];
gdjs.Level4Code.GDTree03aObjects4= [];
gdjs.Level4Code.GDTree03bObjects1= [];
gdjs.Level4Code.GDTree03bObjects2= [];
gdjs.Level4Code.GDTree03bObjects3= [];
gdjs.Level4Code.GDTree03bObjects4= [];
gdjs.Level4Code.GDTree03cObjects1= [];
gdjs.Level4Code.GDTree03cObjects2= [];
gdjs.Level4Code.GDTree03cObjects3= [];
gdjs.Level4Code.GDTree03cObjects4= [];
gdjs.Level4Code.GDTree03dObjects1= [];
gdjs.Level4Code.GDTree03dObjects2= [];
gdjs.Level4Code.GDTree03dObjects3= [];
gdjs.Level4Code.GDTree03dObjects4= [];
gdjs.Level4Code.GDTree03eObjects1= [];
gdjs.Level4Code.GDTree03eObjects2= [];
gdjs.Level4Code.GDTree03eObjects3= [];
gdjs.Level4Code.GDTree03eObjects4= [];
gdjs.Level4Code.GDTree03fObjects1= [];
gdjs.Level4Code.GDTree03fObjects2= [];
gdjs.Level4Code.GDTree03fObjects3= [];
gdjs.Level4Code.GDTree03fObjects4= [];
gdjs.Level4Code.GDTree03gObjects1= [];
gdjs.Level4Code.GDTree03gObjects2= [];
gdjs.Level4Code.GDTree03gObjects3= [];
gdjs.Level4Code.GDTree03gObjects4= [];
gdjs.Level4Code.GDTree03hObjects1= [];
gdjs.Level4Code.GDTree03hObjects2= [];
gdjs.Level4Code.GDTree03hObjects3= [];
gdjs.Level4Code.GDTree03hObjects4= [];

gdjs.Level4Code.conditionTrue_0 = {val:false};
gdjs.Level4Code.condition0IsTrue_0 = {val:false};
gdjs.Level4Code.condition1IsTrue_0 = {val:false};
gdjs.Level4Code.conditionTrue_1 = {val:false};
gdjs.Level4Code.condition0IsTrue_1 = {val:false};
gdjs.Level4Code.condition1IsTrue_1 = {val:false};


gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDMidDirtObjects1ObjectsGDgdjs_46Level4Code_46GDGrassObjects1ObjectsGDgdjs_46Level4Code_46GDDirt_9595GrassObjects1ObjectsGDgdjs_46Level4Code_46GDTopMidDirtObjects1ObjectsGDgdjs_46Level4Code_46GDMidDirt2Objects1ObjectsGDgdjs_46Level4Code_46GDBottomMidDirtObjects1ObjectsGDgdjs_46Level4Code_46GDBottomDirtObjects1ObjectsGDgdjs_46Level4Code_46GDBotBottomObjects1ObjectsGDgdjs_46Level4Code_46GDBottomObjects1ObjectsGDgdjs_46Level4Code_46GDTreeTrunk01Objects1ObjectsGDgdjs_46Level4Code_46GDTree02bObjects1ObjectsGDgdjs_46Level4Code_46GDTree02Objects1ObjectsGDgdjs_46Level4Code_46GDTreeTrunk02Objects1ObjectsGDgdjs_46Level4Code_46GDTree03aObjects1ObjectsGDgdjs_46Level4Code_46GDTree03bObjects1ObjectsGDgdjs_46Level4Code_46GDTree03cObjects1Objects = Hashtable.newFrom({"MidDirt": gdjs.Level4Code.GDMidDirtObjects1, "Grass": gdjs.Level4Code.GDGrassObjects1, "Dirt_Grass": gdjs.Level4Code.GDDirt_95GrassObjects1, "TopMidDirt": gdjs.Level4Code.GDTopMidDirtObjects1, "MidDirt2": gdjs.Level4Code.GDMidDirt2Objects1, "BottomMidDirt": gdjs.Level4Code.GDBottomMidDirtObjects1, "BottomDirt": gdjs.Level4Code.GDBottomDirtObjects1, "BotBottom": gdjs.Level4Code.GDBotBottomObjects1, "Bottom": gdjs.Level4Code.GDBottomObjects1, "TreeTrunk01": gdjs.Level4Code.GDTreeTrunk01Objects1, "Tree02b": gdjs.Level4Code.GDTree02bObjects1, "Tree02": gdjs.Level4Code.GDTree02Objects1, "TreeTrunk02": gdjs.Level4Code.GDTreeTrunk02Objects1, "Tree03a": gdjs.Level4Code.GDTree03aObjects1, "Tree03b": gdjs.Level4Code.GDTree03bObjects1, "Tree03c": gdjs.Level4Code.GDTree03cObjects1});
gdjs.Level4Code.asyncCallback12223828 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects4);

{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects4.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects4[i].getBehavior("Tween").addObjectScaleTween("Size", 1, 1, "bouncePast", 100, false, true);
}
}}
gdjs.Level4Code.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level4Code.GDGoutteObjects3) asyncObjectsList.addObject("Goutte", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level4Code.asyncCallback12223828(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level4Code.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


gdjs.Level4Code.condition0IsTrue_0.val = false;
{
gdjs.Level4Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
}if (gdjs.Level4Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level4Code.GDGoutteObjects3 */
{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects3.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects3[i].getBehavior("Tween").addObjectScaleTween("Size", 0.5, 1, "bouncePast", 100, false, true);
}
}
{ //Subevents
gdjs.Level4Code.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Level4Code.asyncCallback12222772 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects3);

{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects3.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects3[i].getBehavior("Tween").addObjectScaleTween("Size", 1, 1, "bouncePast", 100, false, true);
}
}
{ //Subevents
gdjs.Level4Code.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level4Code.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level4Code.GDGoutteObjects2) asyncObjectsList.addObject("Goutte", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level4Code.asyncCallback12222772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level4Code.asyncCallback12225988 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects4);

{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects4.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects4[i].getBehavior("Tween").addObjectScaleTween("Size", 1, 1, "bouncePast", 100, false, true);
}
}}
gdjs.Level4Code.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level4Code.GDGoutteObjects3) asyncObjectsList.addObject("Goutte", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level4Code.asyncCallback12225988(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level4Code.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


gdjs.Level4Code.condition0IsTrue_0.val = false;
{
gdjs.Level4Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
}if (gdjs.Level4Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level4Code.GDGoutteObjects3 */
{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects3.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects3[i].getBehavior("Tween").addObjectScaleTween("Size", 0.5, 1, "bouncePast", 100, false, true);
}
}
{ //Subevents
gdjs.Level4Code.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Level4Code.asyncCallback12224172 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects3);

{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects3.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects3[i].getBehavior("Tween").addObjectScaleTween("Size", 1, 1, "bouncePast", 100, false, true);
}
}
{ //Subevents
gdjs.Level4Code.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level4Code.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level4Code.GDGoutteObjects2) asyncObjectsList.addObject("Goutte", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level4Code.asyncCallback12224172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level4Code.asyncCallback12228460 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects4);

{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects4.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects4[i].getBehavior("Tween").addObjectScaleTween("Size", 1, 1, "bouncePast", 100, false, true);
}
}}
gdjs.Level4Code.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level4Code.GDGoutteObjects3) asyncObjectsList.addObject("Goutte", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level4Code.asyncCallback12228460(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level4Code.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


gdjs.Level4Code.condition0IsTrue_0.val = false;
{
gdjs.Level4Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up"));
}if (gdjs.Level4Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level4Code.GDGoutteObjects3 */
{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects3.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects3[i].getBehavior("Tween").addObjectScaleTween("Size", 1, 0.5, "bouncePast", 100, false, true);
}
}
{ //Subevents
gdjs.Level4Code.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Level4Code.asyncCallback12227780 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects3);

{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects3.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects3[i].getBehavior("Tween").addObjectScaleTween("Size", 1, 1, "bouncePast", 100, false, true);
}
}
{ //Subevents
gdjs.Level4Code.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level4Code.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level4Code.GDGoutteObjects2) asyncObjectsList.addObject("Goutte", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level4Code.asyncCallback12227780(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level4Code.asyncCallback12231372 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects3);

{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects3.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects3[i].getBehavior("Tween").addObjectScaleTween("Size", 1, 1, "bouncePast", 100, false, true);
}
}}
gdjs.Level4Code.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level4Code.GDGoutteObjects2) asyncObjectsList.addObject("Goutte", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level4Code.asyncCallback12231372(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level4Code.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


gdjs.Level4Code.condition0IsTrue_0.val = false;
{
gdjs.Level4Code.condition0IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down"));
}if (gdjs.Level4Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level4Code.GDGoutteObjects2 */
{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects2.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects2[i].getBehavior("Tween").addObjectScaleTween("Size", 1, 0.5, "bouncePast", 100, false, true);
}
}
{ //Subevents
gdjs.Level4Code.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Level4Code.asyncCallback12230220 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects2);

{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects2.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects2[i].getBehavior("Tween").addObjectScaleTween("Size", 1, 1, "bouncePast", 100, false, true);
}
}
{ //Subevents
gdjs.Level4Code.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level4Code.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level4Code.GDGoutteObjects1) asyncObjectsList.addObject("Goutte", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level4Code.asyncCallback12230220(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level4Code.eventsList12 = function(runtimeScene) {

{


gdjs.Level4Code.condition0IsTrue_0.val = false;
{
gdjs.Level4Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.Level4Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level4Code.GDGoutteObjects1, gdjs.Level4Code.GDGoutteObjects2);

{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects2.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects2[i].getBehavior("Tween").addObjectScaleTween("Size", 1.5, 1, "bouncePast", 100, false, true);
}
}
{ //Subevents
gdjs.Level4Code.eventsList2(runtimeScene);} //End of subevents
}

}


{


gdjs.Level4Code.condition0IsTrue_0.val = false;
{
gdjs.Level4Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.Level4Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level4Code.GDGoutteObjects1, gdjs.Level4Code.GDGoutteObjects2);

{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects2.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects2[i].getBehavior("Tween").addObjectScaleTween("Size", 1.5, 1, "bouncePast", 100, false, true);
}
}
{ //Subevents
gdjs.Level4Code.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.Level4Code.condition0IsTrue_0.val = false;
{
gdjs.Level4Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.Level4Code.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Level4Code.GDGoutteObjects1, gdjs.Level4Code.GDGoutteObjects2);

{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects2.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects2[i].getBehavior("Tween").addObjectScaleTween("Size", 1, 1.5, "bouncePast", 100, false, true);
}
}
{ //Subevents
gdjs.Level4Code.eventsList8(runtimeScene);} //End of subevents
}

}


{


gdjs.Level4Code.condition0IsTrue_0.val = false;
{
gdjs.Level4Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.Level4Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level4Code.GDGoutteObjects1 */
{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects1.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects1[i].getBehavior("Tween").addObjectScaleTween("Size", 1, 1.5, "bouncePast", 100, false, true);
}
}
{ //Subevents
gdjs.Level4Code.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.Level4Code.eventsList13 = function(runtimeScene) {

{


gdjs.Level4Code.eventsList12(runtimeScene);
}


};gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDReadyObjects2Objects = Hashtable.newFrom({"Ready": gdjs.Level4Code.GDReadyObjects2});
gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDGoObjects3Objects = Hashtable.newFrom({"Go": gdjs.Level4Code.GDGoObjects3});
gdjs.Level4Code.asyncCallback12110324 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Go"), gdjs.Level4Code.GDGoObjects4);

{for(var i = 0, len = gdjs.Level4Code.GDGoObjects4.length ;i < len;++i) {
    gdjs.Level4Code.GDGoObjects4[i].deleteFromScene(runtimeScene);
}
}}
gdjs.Level4Code.eventsList14 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level4Code.GDGoObjects3) asyncObjectsList.addObject("Go", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level4Code.asyncCallback12110324(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level4Code.asyncCallback12109428 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects3);

gdjs.copyArray(runtimeScene.getObjects("Pesticide"), gdjs.Level4Code.GDPesticideObjects3);
gdjs.copyArray(asyncObjectsList.getObjects("Ready"), gdjs.Level4Code.GDReadyObjects3);

gdjs.Level4Code.GDGoObjects3.length = 0;

{for(var i = 0, len = gdjs.Level4Code.GDReadyObjects3.length ;i < len;++i) {
    gdjs.Level4Code.GDReadyObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects3.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects3[i].getBehavior("TopDownMovement").ignoreDefaultControls(false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDGoObjects3Objects, (( gdjs.Level4Code.GDGoutteObjects3.length === 0 ) ? 0 :gdjs.Level4Code.GDGoutteObjects3[0].getPointX("")) - 80, (( gdjs.Level4Code.GDGoutteObjects3.length === 0 ) ? 0 :gdjs.Level4Code.GDGoutteObjects3[0].getPointY("")) - 150, "UI");
}{for(var i = 0, len = gdjs.Level4Code.GDPesticideObjects3.length ;i < len;++i) {
    gdjs.Level4Code.GDPesticideObjects3[i].hide();
}
}
{ //Subevents
gdjs.Level4Code.eventsList14(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level4Code.eventsList15 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level4Code.GDGoutteObjects2) asyncObjectsList.addObject("Goutte", obj);
for (const obj of gdjs.Level4Code.GDReadyObjects2) asyncObjectsList.addObject("Ready", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level4Code.asyncCallback12109428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level4Code.asyncCallback12109004 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects2);

gdjs.Level4Code.GDReadyObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDReadyObjects2Objects, (( gdjs.Level4Code.GDGoutteObjects2.length === 0 ) ? 0 :gdjs.Level4Code.GDGoutteObjects2[0].getPointX("")) - 60, (( gdjs.Level4Code.GDGoutteObjects2.length === 0 ) ? 0 :gdjs.Level4Code.GDGoutteObjects2[0].getPointY("")) - 120, "UI");
}
{ //Subevents
gdjs.Level4Code.eventsList15(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level4Code.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level4Code.GDGoutteObjects1) asyncObjectsList.addObject("Goutte", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Level4Code.asyncCallback12109004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level4Code.eventsList17 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Level4Code.GDTimerObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.Level4Code.GDTimerObjects1.length ;i < len;++i) {
    gdjs.Level4Code.GDTimerObjects1[i].setString("Timer: " + gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) / 60)));
}
}}

}


};gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDGoutteObjects1Objects = Hashtable.newFrom({"Goutte": gdjs.Level4Code.GDGoutteObjects1});
gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDNutrientObjects1Objects = Hashtable.newFrom({"Nutrient": gdjs.Level4Code.GDNutrientObjects1});
gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDVictoryObjects1Objects = Hashtable.newFrom({"Victory": gdjs.Level4Code.GDVictoryObjects1});
gdjs.Level4Code.eventsList18 = function(runtimeScene, asyncObjectsList) {

{



}


{


gdjs.Level4Code.condition0IsTrue_0.val = false;
{
{gdjs.Level4Code.conditionTrue_1 = gdjs.Level4Code.condition0IsTrue_0;
gdjs.Level4Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12112748);
}
}if (gdjs.Level4Code.condition0IsTrue_0.val) {
gdjs.copyArray(asyncObjectsList.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects2);

gdjs.copyArray(runtimeScene.getObjects("Pesticide"), gdjs.Level4Code.GDPesticideObjects2);
{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects2.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, 881, -(39));
}
}{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects2.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level4Code.GDPesticideObjects2.length ;i < len;++i) {
    gdjs.Level4Code.GDPesticideObjects2[i].hide(false);
}
}}

}


};gdjs.Level4Code.asyncCallback12112004 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Victory"), gdjs.Level4Code.GDVictoryObjects2);

{for(var i = 0, len = gdjs.Level4Code.GDVictoryObjects2.length ;i < len;++i) {
    gdjs.Level4Code.GDVictoryObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level4Code.eventsList18(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level4Code.eventsList19 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level4Code.GDGoutteObjects1) asyncObjectsList.addObject("Goutte", obj);
for (const obj of gdjs.Level4Code.GDVictoryObjects1) asyncObjectsList.addObject("Victory", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Level4Code.asyncCallback12112004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDGoutteObjects1Objects = Hashtable.newFrom({"Goutte": gdjs.Level4Code.GDGoutteObjects1});
gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.Level4Code.GDExitObjects1});
gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDGoutteObjects1Objects = Hashtable.newFrom({"Goutte": gdjs.Level4Code.GDGoutteObjects1});
gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDPesticideObjects1Objects = Hashtable.newFrom({"Pesticide": gdjs.Level4Code.GDPesticideObjects1});
gdjs.Level4Code.asyncCallback12114604 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level4", false);
}}
gdjs.Level4Code.eventsList20 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Level4Code.asyncCallback12114604(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level4Code.eventsList21 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Level4Code.GDExitObjects1);
{for(var i = 0, len = gdjs.Level4Code.GDExitObjects1.length ;i < len;++i) {
    gdjs.Level4Code.GDExitObjects1[i].hide();
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("BotBottom"), gdjs.Level4Code.GDBotBottomObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bottom"), gdjs.Level4Code.GDBottomObjects1);
gdjs.copyArray(runtimeScene.getObjects("BottomDirt"), gdjs.Level4Code.GDBottomDirtObjects1);
gdjs.copyArray(runtimeScene.getObjects("BottomMidDirt"), gdjs.Level4Code.GDBottomMidDirtObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dirt_Grass"), gdjs.Level4Code.GDDirt_95GrassObjects1);
gdjs.copyArray(runtimeScene.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Grass"), gdjs.Level4Code.GDGrassObjects1);
gdjs.copyArray(runtimeScene.getObjects("MidDirt"), gdjs.Level4Code.GDMidDirtObjects1);
gdjs.copyArray(runtimeScene.getObjects("MidDirt2"), gdjs.Level4Code.GDMidDirt2Objects1);
gdjs.copyArray(runtimeScene.getObjects("TopMidDirt"), gdjs.Level4Code.GDTopMidDirtObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree02"), gdjs.Level4Code.GDTree02Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tree02b"), gdjs.Level4Code.GDTree02bObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree03a"), gdjs.Level4Code.GDTree03aObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree03b"), gdjs.Level4Code.GDTree03bObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree03c"), gdjs.Level4Code.GDTree03cObjects1);
gdjs.copyArray(runtimeScene.getObjects("TreeTrunk01"), gdjs.Level4Code.GDTreeTrunk01Objects1);
gdjs.copyArray(runtimeScene.getObjects("TreeTrunk02"), gdjs.Level4Code.GDTreeTrunk02Objects1);
{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects1.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects1[i].separateFromObjectsList(gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDMidDirtObjects1ObjectsGDgdjs_46Level4Code_46GDGrassObjects1ObjectsGDgdjs_46Level4Code_46GDDirt_9595GrassObjects1ObjectsGDgdjs_46Level4Code_46GDTopMidDirtObjects1ObjectsGDgdjs_46Level4Code_46GDMidDirt2Objects1ObjectsGDgdjs_46Level4Code_46GDBottomMidDirtObjects1ObjectsGDgdjs_46Level4Code_46GDBottomDirtObjects1ObjectsGDgdjs_46Level4Code_46GDBotBottomObjects1ObjectsGDgdjs_46Level4Code_46GDBottomObjects1ObjectsGDgdjs_46Level4Code_46GDTreeTrunk01Objects1ObjectsGDgdjs_46Level4Code_46GDTree02bObjects1ObjectsGDgdjs_46Level4Code_46GDTree02Objects1ObjectsGDgdjs_46Level4Code_46GDTreeTrunk02Objects1ObjectsGDgdjs_46Level4Code_46GDTree03aObjects1ObjectsGDgdjs_46Level4Code_46GDTree03bObjects1ObjectsGDgdjs_46Level4Code_46GDTree03cObjects1Objects, false);
}
}}

}


{



}


{



}


{



}


{



}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects1);

gdjs.Level4Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level4Code.GDGoutteObjects1.length;i<l;++i) {
    if ( gdjs.Level4Code.GDGoutteObjects1[i].getBehavior("TopDownMovement").isMoving() ) {
        gdjs.Level4Code.condition0IsTrue_0.val = true;
        gdjs.Level4Code.GDGoutteObjects1[k] = gdjs.Level4Code.GDGoutteObjects1[i];
        ++k;
    }
}
gdjs.Level4Code.GDGoutteObjects1.length = k;}if (gdjs.Level4Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level4Code.eventsList13(runtimeScene);} //End of subevents
}

}


{


gdjs.Level4Code.condition0IsTrue_0.val = false;
{
gdjs.Level4Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level4Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Retries"), gdjs.Level4Code.GDRetriesObjects1);
{for(var i = 0, len = gdjs.Level4Code.GDRetriesObjects1.length ;i < len;++i) {
    gdjs.Level4Code.GDRetriesObjects1[i].setString("Attempts: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects1.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects1[i].getBehavior("TopDownMovement").ignoreDefaultControls(true);
}
}
{ //Subevents
gdjs.Level4Code.eventsList16(runtimeScene);} //End of subevents
}

}


{


gdjs.Level4Code.eventsList17(runtimeScene);
}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Nutrient"), gdjs.Level4Code.GDNutrientObjects1);

gdjs.Level4Code.condition0IsTrue_0.val = false;
{
gdjs.Level4Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDGoutteObjects1Objects, gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDNutrientObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level4Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level4Code.GDGoutteObjects1 */
/* Reuse gdjs.Level4Code.GDNutrientObjects1 */
gdjs.Level4Code.GDVictoryObjects1.length = 0;

{for(var i = 0, len = gdjs.Level4Code.GDNutrientObjects1.length ;i < len;++i) {
    gdjs.Level4Code.GDNutrientObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects1.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects1[i].getBehavior("TopDownMovement").ignoreDefaultControls(true);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDVictoryObjects1Objects, (( gdjs.Level4Code.GDGoutteObjects1.length === 0 ) ? 0 :gdjs.Level4Code.GDGoutteObjects1[0].getPointX("")) - 200, (( gdjs.Level4Code.GDGoutteObjects1.length === 0 ) ? 0 :gdjs.Level4Code.GDGoutteObjects1[0].getPointY("")) - 100, "UI");
}
{ //Subevents
gdjs.Level4Code.eventsList19(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Level4Code.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects1);

gdjs.Level4Code.condition0IsTrue_0.val = false;
{
gdjs.Level4Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDGoutteObjects1Objects, gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDExitObjects1Objects, false, runtimeScene, false);
}if (gdjs.Level4Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level5", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Goutte"), gdjs.Level4Code.GDGoutteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Pesticide"), gdjs.Level4Code.GDPesticideObjects1);

gdjs.Level4Code.condition0IsTrue_0.val = false;
{
gdjs.Level4Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDGoutteObjects1Objects, gdjs.Level4Code.mapOfGDgdjs_46Level4Code_46GDPesticideObjects1Objects, false, runtimeScene, true);
}if (gdjs.Level4Code.condition0IsTrue_0.val) {
/* Reuse gdjs.Level4Code.GDGoutteObjects1 */
/* Reuse gdjs.Level4Code.GDPesticideObjects1 */
{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects1.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level4Code.GDGoutteObjects1.length ;i < len;++i) {
    gdjs.Level4Code.GDGoutteObjects1[i].getBehavior("TopDownMovement").ignoreDefaultControls(true);
}
}{for(var i = 0, len = gdjs.Level4Code.GDPesticideObjects1.length ;i < len;++i) {
    gdjs.Level4Code.GDPesticideObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.Level4Code.eventsList20(runtimeScene);} //End of subevents
}

}


};

gdjs.Level4Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level4Code.GDGoutteObjects1.length = 0;
gdjs.Level4Code.GDGoutteObjects2.length = 0;
gdjs.Level4Code.GDGoutteObjects3.length = 0;
gdjs.Level4Code.GDGoutteObjects4.length = 0;
gdjs.Level4Code.GDBackgroundSkyObjects1.length = 0;
gdjs.Level4Code.GDBackgroundSkyObjects2.length = 0;
gdjs.Level4Code.GDBackgroundSkyObjects3.length = 0;
gdjs.Level4Code.GDBackgroundSkyObjects4.length = 0;
gdjs.Level4Code.GDNutrientObjects1.length = 0;
gdjs.Level4Code.GDNutrientObjects2.length = 0;
gdjs.Level4Code.GDNutrientObjects3.length = 0;
gdjs.Level4Code.GDNutrientObjects4.length = 0;
gdjs.Level4Code.GDGrassObjects1.length = 0;
gdjs.Level4Code.GDGrassObjects2.length = 0;
gdjs.Level4Code.GDGrassObjects3.length = 0;
gdjs.Level4Code.GDGrassObjects4.length = 0;
gdjs.Level4Code.GDDirt_95GrassObjects1.length = 0;
gdjs.Level4Code.GDDirt_95GrassObjects2.length = 0;
gdjs.Level4Code.GDDirt_95GrassObjects3.length = 0;
gdjs.Level4Code.GDDirt_95GrassObjects4.length = 0;
gdjs.Level4Code.GDTopMidDirtObjects1.length = 0;
gdjs.Level4Code.GDTopMidDirtObjects2.length = 0;
gdjs.Level4Code.GDTopMidDirtObjects3.length = 0;
gdjs.Level4Code.GDTopMidDirtObjects4.length = 0;
gdjs.Level4Code.GDMidDirtObjects1.length = 0;
gdjs.Level4Code.GDMidDirtObjects2.length = 0;
gdjs.Level4Code.GDMidDirtObjects3.length = 0;
gdjs.Level4Code.GDMidDirtObjects4.length = 0;
gdjs.Level4Code.GDMidDirt2Objects1.length = 0;
gdjs.Level4Code.GDMidDirt2Objects2.length = 0;
gdjs.Level4Code.GDMidDirt2Objects3.length = 0;
gdjs.Level4Code.GDMidDirt2Objects4.length = 0;
gdjs.Level4Code.GDBottomMidDirtObjects1.length = 0;
gdjs.Level4Code.GDBottomMidDirtObjects2.length = 0;
gdjs.Level4Code.GDBottomMidDirtObjects3.length = 0;
gdjs.Level4Code.GDBottomMidDirtObjects4.length = 0;
gdjs.Level4Code.GDBottomObjects1.length = 0;
gdjs.Level4Code.GDBottomObjects2.length = 0;
gdjs.Level4Code.GDBottomObjects3.length = 0;
gdjs.Level4Code.GDBottomObjects4.length = 0;
gdjs.Level4Code.GDBottomDirtObjects1.length = 0;
gdjs.Level4Code.GDBottomDirtObjects2.length = 0;
gdjs.Level4Code.GDBottomDirtObjects3.length = 0;
gdjs.Level4Code.GDBottomDirtObjects4.length = 0;
gdjs.Level4Code.GDBotBottomObjects1.length = 0;
gdjs.Level4Code.GDBotBottomObjects2.length = 0;
gdjs.Level4Code.GDBotBottomObjects3.length = 0;
gdjs.Level4Code.GDBotBottomObjects4.length = 0;
gdjs.Level4Code.GDRacineObjects1.length = 0;
gdjs.Level4Code.GDRacineObjects2.length = 0;
gdjs.Level4Code.GDRacineObjects3.length = 0;
gdjs.Level4Code.GDRacineObjects4.length = 0;
gdjs.Level4Code.GDPesticideObjects1.length = 0;
gdjs.Level4Code.GDPesticideObjects2.length = 0;
gdjs.Level4Code.GDPesticideObjects3.length = 0;
gdjs.Level4Code.GDPesticideObjects4.length = 0;
gdjs.Level4Code.GDTimerObjects1.length = 0;
gdjs.Level4Code.GDTimerObjects2.length = 0;
gdjs.Level4Code.GDTimerObjects3.length = 0;
gdjs.Level4Code.GDTimerObjects4.length = 0;
gdjs.Level4Code.GDRetriesObjects1.length = 0;
gdjs.Level4Code.GDRetriesObjects2.length = 0;
gdjs.Level4Code.GDRetriesObjects3.length = 0;
gdjs.Level4Code.GDRetriesObjects4.length = 0;
gdjs.Level4Code.GDExitObjects1.length = 0;
gdjs.Level4Code.GDExitObjects2.length = 0;
gdjs.Level4Code.GDExitObjects3.length = 0;
gdjs.Level4Code.GDExitObjects4.length = 0;
gdjs.Level4Code.GDSunObjects1.length = 0;
gdjs.Level4Code.GDSunObjects2.length = 0;
gdjs.Level4Code.GDSunObjects3.length = 0;
gdjs.Level4Code.GDSunObjects4.length = 0;
gdjs.Level4Code.GDTreeTrunk01Objects1.length = 0;
gdjs.Level4Code.GDTreeTrunk01Objects2.length = 0;
gdjs.Level4Code.GDTreeTrunk01Objects3.length = 0;
gdjs.Level4Code.GDTreeTrunk01Objects4.length = 0;
gdjs.Level4Code.GDTreeTrunk02Objects1.length = 0;
gdjs.Level4Code.GDTreeTrunk02Objects2.length = 0;
gdjs.Level4Code.GDTreeTrunk02Objects3.length = 0;
gdjs.Level4Code.GDTreeTrunk02Objects4.length = 0;
gdjs.Level4Code.GDTreeTrunk03Objects1.length = 0;
gdjs.Level4Code.GDTreeTrunk03Objects2.length = 0;
gdjs.Level4Code.GDTreeTrunk03Objects3.length = 0;
gdjs.Level4Code.GDTreeTrunk03Objects4.length = 0;
gdjs.Level4Code.GDTreeTrunk04Objects1.length = 0;
gdjs.Level4Code.GDTreeTrunk04Objects2.length = 0;
gdjs.Level4Code.GDTreeTrunk04Objects3.length = 0;
gdjs.Level4Code.GDTreeTrunk04Objects4.length = 0;
gdjs.Level4Code.GDGoObjects1.length = 0;
gdjs.Level4Code.GDGoObjects2.length = 0;
gdjs.Level4Code.GDGoObjects3.length = 0;
gdjs.Level4Code.GDGoObjects4.length = 0;
gdjs.Level4Code.GDReadyObjects1.length = 0;
gdjs.Level4Code.GDReadyObjects2.length = 0;
gdjs.Level4Code.GDReadyObjects3.length = 0;
gdjs.Level4Code.GDReadyObjects4.length = 0;
gdjs.Level4Code.GDVictoryObjects1.length = 0;
gdjs.Level4Code.GDVictoryObjects2.length = 0;
gdjs.Level4Code.GDVictoryObjects3.length = 0;
gdjs.Level4Code.GDVictoryObjects4.length = 0;
gdjs.Level4Code.GDBigRockObjects1.length = 0;
gdjs.Level4Code.GDBigRockObjects2.length = 0;
gdjs.Level4Code.GDBigRockObjects3.length = 0;
gdjs.Level4Code.GDBigRockObjects4.length = 0;
gdjs.Level4Code.GDBigRock_95BotLeftObjects1.length = 0;
gdjs.Level4Code.GDBigRock_95BotLeftObjects2.length = 0;
gdjs.Level4Code.GDBigRock_95BotLeftObjects3.length = 0;
gdjs.Level4Code.GDBigRock_95BotLeftObjects4.length = 0;
gdjs.Level4Code.GDBigRock_95BotRightObjects1.length = 0;
gdjs.Level4Code.GDBigRock_95BotRightObjects2.length = 0;
gdjs.Level4Code.GDBigRock_95BotRightObjects3.length = 0;
gdjs.Level4Code.GDBigRock_95BotRightObjects4.length = 0;
gdjs.Level4Code.GDBigRock_95TopLeftObjects1.length = 0;
gdjs.Level4Code.GDBigRock_95TopLeftObjects2.length = 0;
gdjs.Level4Code.GDBigRock_95TopLeftObjects3.length = 0;
gdjs.Level4Code.GDBigRock_95TopLeftObjects4.length = 0;
gdjs.Level4Code.GDBigRock_95TopRighObjects1.length = 0;
gdjs.Level4Code.GDBigRock_95TopRighObjects2.length = 0;
gdjs.Level4Code.GDBigRock_95TopRighObjects3.length = 0;
gdjs.Level4Code.GDBigRock_95TopRighObjects4.length = 0;
gdjs.Level4Code.GDMediumRockObjects1.length = 0;
gdjs.Level4Code.GDMediumRockObjects2.length = 0;
gdjs.Level4Code.GDMediumRockObjects3.length = 0;
gdjs.Level4Code.GDMediumRockObjects4.length = 0;
gdjs.Level4Code.GDMediumRock_95BotLeftObjects1.length = 0;
gdjs.Level4Code.GDMediumRock_95BotLeftObjects2.length = 0;
gdjs.Level4Code.GDMediumRock_95BotLeftObjects3.length = 0;
gdjs.Level4Code.GDMediumRock_95BotLeftObjects4.length = 0;
gdjs.Level4Code.GDMediumRock_95BotRightObjects1.length = 0;
gdjs.Level4Code.GDMediumRock_95BotRightObjects2.length = 0;
gdjs.Level4Code.GDMediumRock_95BotRightObjects3.length = 0;
gdjs.Level4Code.GDMediumRock_95BotRightObjects4.length = 0;
gdjs.Level4Code.GDMediumRock_95TopLeftObjects1.length = 0;
gdjs.Level4Code.GDMediumRock_95TopLeftObjects2.length = 0;
gdjs.Level4Code.GDMediumRock_95TopLeftObjects3.length = 0;
gdjs.Level4Code.GDMediumRock_95TopLeftObjects4.length = 0;
gdjs.Level4Code.GDMediumRock_95TopRightObjects1.length = 0;
gdjs.Level4Code.GDMediumRock_95TopRightObjects2.length = 0;
gdjs.Level4Code.GDMediumRock_95TopRightObjects3.length = 0;
gdjs.Level4Code.GDMediumRock_95TopRightObjects4.length = 0;
gdjs.Level4Code.GDSideWall_95CornerObjects1.length = 0;
gdjs.Level4Code.GDSideWall_95CornerObjects2.length = 0;
gdjs.Level4Code.GDSideWall_95CornerObjects3.length = 0;
gdjs.Level4Code.GDSideWall_95CornerObjects4.length = 0;
gdjs.Level4Code.GDTileSideWall_95DoubleObjects1.length = 0;
gdjs.Level4Code.GDTileSideWall_95DoubleObjects2.length = 0;
gdjs.Level4Code.GDTileSideWall_95DoubleObjects3.length = 0;
gdjs.Level4Code.GDTileSideWall_95DoubleObjects4.length = 0;
gdjs.Level4Code.GDTileSideWallObjects1.length = 0;
gdjs.Level4Code.GDTileSideWallObjects2.length = 0;
gdjs.Level4Code.GDTileSideWallObjects3.length = 0;
gdjs.Level4Code.GDTileSideWallObjects4.length = 0;
gdjs.Level4Code.GDTileRacine01Objects1.length = 0;
gdjs.Level4Code.GDTileRacine01Objects2.length = 0;
gdjs.Level4Code.GDTileRacine01Objects3.length = 0;
gdjs.Level4Code.GDTileRacine01Objects4.length = 0;
gdjs.Level4Code.GDExplosionObjects1.length = 0;
gdjs.Level4Code.GDExplosionObjects2.length = 0;
gdjs.Level4Code.GDExplosionObjects3.length = 0;
gdjs.Level4Code.GDExplosionObjects4.length = 0;
gdjs.Level4Code.GDTree02Objects1.length = 0;
gdjs.Level4Code.GDTree02Objects2.length = 0;
gdjs.Level4Code.GDTree02Objects3.length = 0;
gdjs.Level4Code.GDTree02Objects4.length = 0;
gdjs.Level4Code.GDTree02bObjects1.length = 0;
gdjs.Level4Code.GDTree02bObjects2.length = 0;
gdjs.Level4Code.GDTree02bObjects3.length = 0;
gdjs.Level4Code.GDTree02bObjects4.length = 0;
gdjs.Level4Code.GDTree02cObjects1.length = 0;
gdjs.Level4Code.GDTree02cObjects2.length = 0;
gdjs.Level4Code.GDTree02cObjects3.length = 0;
gdjs.Level4Code.GDTree02cObjects4.length = 0;
gdjs.Level4Code.GDTree02dObjects1.length = 0;
gdjs.Level4Code.GDTree02dObjects2.length = 0;
gdjs.Level4Code.GDTree02dObjects3.length = 0;
gdjs.Level4Code.GDTree02dObjects4.length = 0;
gdjs.Level4Code.GDTree02eObjects1.length = 0;
gdjs.Level4Code.GDTree02eObjects2.length = 0;
gdjs.Level4Code.GDTree02eObjects3.length = 0;
gdjs.Level4Code.GDTree02eObjects4.length = 0;
gdjs.Level4Code.GDTree02fObjects1.length = 0;
gdjs.Level4Code.GDTree02fObjects2.length = 0;
gdjs.Level4Code.GDTree02fObjects3.length = 0;
gdjs.Level4Code.GDTree02fObjects4.length = 0;
gdjs.Level4Code.GDTree03aObjects1.length = 0;
gdjs.Level4Code.GDTree03aObjects2.length = 0;
gdjs.Level4Code.GDTree03aObjects3.length = 0;
gdjs.Level4Code.GDTree03aObjects4.length = 0;
gdjs.Level4Code.GDTree03bObjects1.length = 0;
gdjs.Level4Code.GDTree03bObjects2.length = 0;
gdjs.Level4Code.GDTree03bObjects3.length = 0;
gdjs.Level4Code.GDTree03bObjects4.length = 0;
gdjs.Level4Code.GDTree03cObjects1.length = 0;
gdjs.Level4Code.GDTree03cObjects2.length = 0;
gdjs.Level4Code.GDTree03cObjects3.length = 0;
gdjs.Level4Code.GDTree03cObjects4.length = 0;
gdjs.Level4Code.GDTree03dObjects1.length = 0;
gdjs.Level4Code.GDTree03dObjects2.length = 0;
gdjs.Level4Code.GDTree03dObjects3.length = 0;
gdjs.Level4Code.GDTree03dObjects4.length = 0;
gdjs.Level4Code.GDTree03eObjects1.length = 0;
gdjs.Level4Code.GDTree03eObjects2.length = 0;
gdjs.Level4Code.GDTree03eObjects3.length = 0;
gdjs.Level4Code.GDTree03eObjects4.length = 0;
gdjs.Level4Code.GDTree03fObjects1.length = 0;
gdjs.Level4Code.GDTree03fObjects2.length = 0;
gdjs.Level4Code.GDTree03fObjects3.length = 0;
gdjs.Level4Code.GDTree03fObjects4.length = 0;
gdjs.Level4Code.GDTree03gObjects1.length = 0;
gdjs.Level4Code.GDTree03gObjects2.length = 0;
gdjs.Level4Code.GDTree03gObjects3.length = 0;
gdjs.Level4Code.GDTree03gObjects4.length = 0;
gdjs.Level4Code.GDTree03hObjects1.length = 0;
gdjs.Level4Code.GDTree03hObjects2.length = 0;
gdjs.Level4Code.GDTree03hObjects3.length = 0;
gdjs.Level4Code.GDTree03hObjects4.length = 0;

gdjs.Level4Code.eventsList21(runtimeScene);

return;

}

gdjs['Level4Code'] = gdjs.Level4Code;
